<?php
$SES = array (
  '10e773d22c9507161b4fe2e085a9158f' => 
  array (
    'cfg' => 
    array (
      'charsets' => 'utf8 latin1',
      'lang' => 'ru',
      'time_web' => '600',
      'time_cron' => '600',
      'backup_path' => '/home/vamshop/www/admin/backups/',
      'backup_url' => 'http://vamshop.loc/admin/backups/',
      'only_create' => 'MRG_MyISAM MERGE HEAP MEMORY',
      'globstat' => 0,
      'my_host' => 'localhost',
      'my_port' => 3306,
      'my_user' => 'root',
      'my_pass' => '',
      'my_comp' => 0,
      'my_db' => 'vamshop',
      'auth' => 'vam',
      'user' => '',
      'pass' => '',
      'confirm' => '6',
      'exitURL' => 'http://vamshop.loc/admin/start.php',
    ),
    'time' => 1390330519,
    'lng' => 'ru',
  ),
);
?>