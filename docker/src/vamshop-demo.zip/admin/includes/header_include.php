<?php
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/javascript/script_header_local.php');
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/javascript/script_header.php');
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/css/css_header_local.php');
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/css/css_header.php');
?>