<?php
/* --------------------------------------------------------------
   $Id: footer.php 899 2007-02-08 12:09:57 VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   --------------------------------------------------------------
   based on: 
   (c) 2000-2001 The Exchange Project  (earlier name of osCommerce)
   (c) 2002-2003 osCommerce(footer.php,v 1.12 2003/02/17); www.oscommerce.com 
   (c) 2003	 nextcommerce (footer.php,v 1.11 2003/08/18); www.nextcommerce.org
   (c) 2004	 xt:Commerce (footer.php,v 1.11 2003/08/18); xt-commerce.com

   Released under the GNU General Public License 
   --------------------------------------------------------------*/
?>


									</div>
								</div>
<!--								<div id="styleSelector" class="closed">
									<div class="selector-toggle">
										<a href="javascript:void(0)"></a>
									</div> 
									<ul>
										<li>
											<p class="selector-title">Style Selector</p>
										</li>
										<li class="theme-option">
											<span class="sub-title">Left Header Theme</span>
											<div class="theme-color">
												<a href="#" class="leftheader-theme" lheader-theme="theme1">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme2">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme3">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme4">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme5">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme6">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme7">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme8">&nbsp;</a>
												<a href="#" class="leftheader-theme" lheader-theme="theme9">&nbsp;</a> 
											</div>
										</li>
										<li class="theme-option">
											<span class="sub-title">Header Theme</span>
											<div class="theme-color">
												<a href="#" class="header-theme" header-theme="theme1">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme2">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme3">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme4">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme5">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme6">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme7">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme8">&nbsp;</a>
												<a href="#" class="header-theme" header-theme="theme9">&nbsp;</a> 
											</div>
										</li>
										<li class="theme-option">
											<span class="sub-title">left NavBar Theme</span>
											<div class="theme-color">
												<a href="#" class="navbar-theme" navbar-theme="theme1">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme2">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme3">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme4">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme5">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme6">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme7">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme8">&nbsp;</a>
												<a href="#" class="navbar-theme" navbar-theme="theme9">&nbsp;</a> 
											</div>
										</li>
										<li class="theme-option">
											<span class="sub-title">Active item Theme</span>
											<div class="theme-color">
												<a href="#" class="active-item-theme" active-item-theme="theme1">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme2">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme3">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme4">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme5">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme6">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme7">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme8">&nbsp;</a>
												<a href="#" class="active-item-theme" active-item-theme="theme9">&nbsp;</a>
											</div>
										</li>   
										<li class="theme-option">
											<span class="sub-title">Background Patterns</span>
											<div class="theme-color">
												<a href="#" class="themebg-pattern" themebg-pattern="pattern1">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern2">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern3">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern4">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern5">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern6">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern7">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern8">&nbsp;</a>
												<a href="#" class="themebg-pattern" themebg-pattern="pattern9">&nbsp;</a>
											</div>
										</li>  
										<li class="theme-option">
											<span class="sub-title">Sidebar Position</span> 
											<div class="slideOne">	
												<input type="checkbox" value="false" id="sidebar-position" name="sidebar-position"> 
												<label for="slideOne">Fixed Sidebar Position</label>
											</div> 
										</li>
										<li class="theme-option">
											<span class="sub-title">Header Position</span> 
											<div class="slideOne">	
												<input type="checkbox" value="false" id="header-position" name="header-position"> 
												<label for="slideOne">Fixed Header Position</label>
											</div> 
										</li>
										
										<li class="theme-option">
											<span class="sub-title">Item Border</span> 
											<div class="slideOne">	
												<input type="checkbox" value="false" id="vertical-item-border" name="vertical-item-border"> 
												<label for="slideOne">Hide Item Border</label>
											</div>
											
										</li>
										<li class="theme-option">
											<span class="sub-title">SubItem Border</span> 
											<div class="slideOne">	
												<input type="checkbox" value="false" id="vertical-subitem-border" name="vertical-item-border"> 
												<label for="slideOne">Hide SubItem Border</label>
											</div> 
										</li>  
										<li class="theme-option">
											<span class="sub-title">Theme vertical Layout</span>
											<select id="theme-layout" class="form-control minimal input-sm">
												<option name="vertical-layout" value="wide">Wide layout</option>
												<option name="vertical-layout" value="box">Boxed layout</option>
												<option name="vertical-layout" value="widebox">widebox layout</option> 
											</select>
										</li>
										<li class="theme-option">
											<span class="sub-title">SideBar Effect</span>
											<select id="vertical-menu-effect" class="form-control minimal input-sm">
												<option name="vertical-menu-effect" value="shrink">shrink</option>
												<option name="vertical-menu-effect" value="overlay">overlay</option>
												<option name="vertical-menu-effect" value="push">Push</option>
											</select>
										</li>   
										<li class="theme-option">
											<span class="sub-title">Border Style</span>
											<select id="vertical-border-style" class="form-control minimal input-sm">
												<option name="vertical-border-style" value="solid">Style 1</option>
												<option name="vertical-border-style" value="dotted">style 2</option>
												<option name="vertical-border-style" value="dashed">style 3</option> 
											</select>
										</li>
										<li class="theme-option">
											<span class="sub-title">DropDown Icon</span>
											<select id="vertical-dropdown-icon" class="form-control minimal input-sm">
												<option name="vertical-dropdown-icon" value="style1">Style 1</option>
												<option name="vertical-dropdown-icon" value="style2">style 2</option>
												<option name="vertical-dropdown-icon" value="style3">style 3</option> 
											</select>
										</li>
										<li class="theme-option">
											<span class="sub-title">Submenu Item Icon</span>
											<select id="vertical-subitem-icon" class="form-control minimal input-sm">
												<option name="vertical-subitem-icon" value="style1">Style 1</option>
												<option name="vertical-subitem-icon" value="style2">style 2</option>
												<option name="vertical-subitem-icon" value="style3">style 3</option>
												<option name="vertical-subitem-icon" value="style4">style 4</option> 
												<option name="vertical-subitem-icon" value="style5">style 5</option> 
												<option name="vertical-subitem-icon" value="style6">style 6</option> 
											</select>
										</li>
									</ul>
								</div>-->
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>


<br>
<table border="0" width="100%" cellspacing="0" cellpadding="2">
  <tr>
    <td align="center" class="smallText"><?php
/*
  The following copyright announcement is in compliance
  to section 2c of the GNU General Public License, and
  thus can not be removed, or can only be modified
  appropriately.

  For more information please read the osCommerce
  Copyright Policy at:

  http://www.oscommerce.com/about/copyright

  Please leave this comment intact together with the
  following copyright announcement.
*/
?>
<p>
<?php echo VAMSHOP_SUPPORT_KEY_TEXT; ?>
<?php echo VAMSHOP_SUPPORT_KEY; ?>
</p>
  </td>
  </tr>
</table>

<?php
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/javascript/script_footer_local.php');
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/javascript/script_footer.php');
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/css/css_footer_local.php');
include(DIR_FS_ADMIN.DIR_WS_INCLUDES.'/css/css_footer.php');
?>