var fdLocale = {
        months:[
                "Enero",
                "Febrero",
                "Marzo",
                "Abril",
                "Mayo",
                "Junio",
                "Julio",
                "Agosto",
                "Septiembre",
                "Octubre",
                "Noviembre",
                "Diciembre"
                ],
        fullDay:[
                "Lunes",
                "Martes",
                "Miйrcoles",
                "Jueves",
                "Viernes",
                "Sбbado",
                "Domingo"
                ],
        /* Only stipulate the dayAbbr should the first letter of the fullDay not suffice

        dayAbbr:[],
        */

        /* Only stipulate the firstDayOfWeek should the first day not be Monday

        firstDayOfWeek:0,
        */
        titles:[
                "Mes Anterior",
                "Mes Siguiente",
                "Aсo anterior",
                "Aсo Siguiente"
                ]
};
