<script src="<?php echo DIR_WS_CATALOG; ?>jscript/jquery/plugins/scrollup/jquery.scrollup.min.js"></script>
<script src="<?php echo DIR_WS_ADMIN; ?>includes/javascript/vamshop.js"></script>
