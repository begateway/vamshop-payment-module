<?php if (ADMIN_DROP_DOWN_NAVIGATION == 'true') { ?>
<link href="includes/javascript/vamshop-menu/css/vamshop-menu-horizontal.min.css" rel="stylesheet">
<?php } else { ?>
<link href="includes/javascript/vamshop-menu/css/vamshop-menu-vertical.min.css" rel="stylesheet">
<?php } ?>

<link href="includes/javascript/vamshop-menu/css/jquery.mCustomScrollbar.css" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="includes/css/bootstrap4/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="includes/css/fontawesome/font-awesome.css">
<link rel="stylesheet" type="text/css" href="includes/css/fontroboto/font-roboto.css">
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">

<link type="text/css" href="../jscript/jquery/plugins/ui/css/smoothness/jquery-ui.css" rel="stylesheet" />	

<link rel="stylesheet" type="text/css" href="/jscript/jquery/plugins/select2/select2.css">
<link rel="stylesheet" type="text/css" href="/jscript/jquery/plugins/select2/select2-bootstrap.css">
