<?php
/* --------------------------------------------------------------
   $Id: new_attributes.php 1313 2007-02-08 11:13:01Z VaM $   

   VaM Shop - open source ecommerce solution
   http://vamshop.ru
   http://vamshop.com

   Copyright (c) 2007 VaM Shop
   --------------------------------------------------------------
   based on:
   (c) 2004 xt:Commerce (orders_actions.php,v 1.13 2003/08/21); xt-commerce.com

   Released under the GNU General Public License
   --------------------------------------------------------------*/
   
?>